# place-review

Personal-use review collection and analysis tool.

## Stack
- Backend: FastAPI
- Frontend: Next.js (React)
- State: Zustand
- Data fetching: React Query
- Database: Postgres
- Scraping: Selenium (with Playwright as a future alternative)

## Repository layout
- `backend/`: FastAPI service (API, scraping, analysis)
- `frontend/`: Next.js UI
- `shared/`: Shared types/utilities

## Backend quickstart
See `backend/README.md`.
