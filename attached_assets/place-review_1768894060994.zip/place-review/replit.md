# Place Review Analyzer

A full-stack application for analyzing place reviews from Naver.

For detailed architecture documentation, see [ARCHITECTURE.md](./ARCHITECTURE.md).

## Overview

This project consists of:
- **Frontend**: Next.js 14 application running on port 5000
- **Backend**: FastAPI application running on port 8000
- **Database**: PostgreSQL

## Project Structure

```
backend/
  app/
    api/        - API routes (health, jobs)
    core/       - Core settings
    db/         - Database models and session
    jobs/       - Background job handling
    models/     - Pydantic models
    services/   - Business logic services
  alembic/      - Database migrations
  tests/        - Test files

frontend/
  app/          - Next.js app router pages
  lib/          - API client utilities
  hooks/        - React hooks (useJobStatus)
  store/        - Zustand state management
```

## Running the Application

The application is configured to run via the "Start application" workflow which:
1. Starts Redis server for job queue management
2. Starts RQ worker for background job processing
3. Starts the FastAPI backend on localhost:8000
4. Starts the Next.js frontend on 0.0.0.0:5000
5. Frontend proxies /api/* requests to the backend

## Environment Variables

- `APP_ENV`: Application environment (dev/prod)
- `DATABASE_URL`: PostgreSQL connection string (auto-configured)

## Recent Updates (2026-01-16)

### Input Simplification
- Changed from full URL input to place_id only input (e.g., `1414590796`)
- Backend constructs full URL from place_id: `https://m.place.naver.com/place/{place_id}`

### Date Range Mode
- Added DATE_RANGE mode with start_date and end_date for collecting reviews within a specific period
- DATE mode now uses start_date (reviews from that date onwards)
- Proper validation: start_date must be before or equal to end_date

### Previous Updates
- Replaced Selenium with Playwright for web scraping (better Replit compatibility)
- Installed system Chromium and required libraries via Nix
- Updated CSS selectors for current Naver Place page structure
- Added automatic navigation to review tab (`/review/visitor`)
- Multiple fallback selectors for robust review extraction

## Architecture Notes

- Frontend uses Next.js rewrites to proxy API calls to the backend
- Backend uses SQLAlchemy with psycopg for PostgreSQL connectivity
- The database URL is automatically converted from `postgresql://` to `postgresql+psycopg://` format

## Deployment

### Scripts
- `build.sh`: 빌드 스크립트 (Python 의존성 + Playwright + 프론트엔드 빌드)
- `start-prod.sh`: 프로덕션 실행 스크립트 (Redis + RQ 워커 + 백엔드 + 프론트엔드)
- `start.sh`: 개발 환경 실행 스크립트

### Deployment Configuration
- **타입**: VM (백그라운드 프로세스 필요)
- **빌드**: `bash ./build.sh`
- **실행**: `bash ./start-prod.sh`

## Deployment Troubleshooting

### 오류 기록 및 해결 방법

| 오류 | 원인 | 해결 방법 |
|------|------|-----------|
| `package.json not found in workspace root` | `bash -c "cd frontend && npm..."` 구문에서 서브쉘 컨텍스트 유실 | 별도 빌드 스크립트(`build.sh`) 생성하여 `cd` 후 명령 실행 |
| `npm ci lockfileVersion 3 requires npm >= 7` | 배포 환경의 npm 버전 호환성 문제 | `npm ci` 대신 `npm install` 사용 |
| `localhost binding not accessible` | 배포 환경에서 외부 헬스체크 불가 | 백엔드를 `0.0.0.0`으로 바인딩 |
| `npm --prefix frontend ci invalid syntax` | 일부 환경에서 `--prefix` 구문 지원 안됨 | `cd frontend && npm...` 또는 서브쉘 `(cd frontend && npm...)` 사용 |
| `working directory context lost` | bash 명령에서 `cd` 후 컨텍스트 유실 | 서브쉘 `()` 사용: `(cd backend && uvicorn ...) &` |
| `Deployment timed out` | 서비스 시작이 너무 느려 헬스체크 실패 | `sleep` 제거, 프론트엔드를 `exec`로 메인 프로세스로 실행 |
| `APP_ENV missing` | 배포 환경에서 환경변수 미설정으로 백엔드 시작 실패 | Settings에 기본값 설정 (`app_env: str = "prod"`) 및 production 환경변수 설정 |
| `Nix layers uncached timeout` | Nix 패키지가 너무 커서 Bundle 단계에서 타임아웃 | 불필요한 Nix 패키지 제거, 최소한의 패키지만 유지 |
| `playwright install chromium timeout` | build.sh에서 Chromium 다운로드로 빌드 타임아웃 | 시스템 Chromium 사용, `playwright install chromium` 제거 |

### Nix 패키지 최적화 원칙
- **필수 패키지만 설치**: 불필요한 패키지는 Bundle 크기를 증가시켜 배포 타임아웃 유발
- **현재 필수 패키지**: `chromium`, `nspr`, `nss`, `redis`
- **제거된 패키지**: `playwright-driver`, `gtk3`, `mesa`, `alsa-lib`, `cups`, `gitFull`, `pango`, X11 라이브러리들
- Chromium 의존성 라이브러리는 Nix가 자동으로 관리하므로 별도 설치 불필요

### 배포 시 체크리스트
1. 백엔드가 `0.0.0.0`에 바인딩되어 있는지 확인
2. 빌드 스크립트에서 Python 의존성 설치 포함 여부 확인
3. `playwright install chromium` 제거 확인 (시스템 Chromium 사용)
4. 프론트엔드가 프로덕션 모드(`npm run start`)로 실행되는지 확인
5. Redis 서버 시작이 실행 스크립트에 포함되어 있는지 확인
6. Nix 패키지가 최소화되어 있는지 확인 (Bundle 타임아웃 방지)
7. `.replit`에 단일 외부 포트(5000→80)만 설정되어 있는지 확인
